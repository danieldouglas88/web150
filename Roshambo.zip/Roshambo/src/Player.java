
public abstract class Player {
	
	String name; String roshambo;
	
	abstract void setName(String name);
	
	abstract String getName();
	
	abstract void setRoshambo(String roshambo);
	
	abstract String getRoshambo();
	
	abstract String generateRoshambo(); }
