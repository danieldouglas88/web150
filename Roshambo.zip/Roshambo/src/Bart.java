
public class Bart extends Player {
	Roshambo p1 = Roshambo.rock; 
	
	@Override
	public String generateRoshambo() {
		return p1.toString();}

	@Override
	void setName(String name) {
		this.name = name; }

	@Override
	String getName() {
		return name; }

	@Override
	void setRoshambo(String roshambo) {
		this.roshambo = roshambo; }

	@Override
	String getRoshambo() {
		return roshambo;}}