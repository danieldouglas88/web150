
public class Player1 extends Player {
	
	Roshambo p1 = Roshambo.rock; 
	Roshambo p2 = Roshambo.paper; 
	Roshambo p3 = Roshambo.scissors; 
	
	@Override
	void setName(String name) {
		this.name = name;}

	@Override
	String getName() {
		return name; }

	@Override
	void setRoshambo(String roshambo) {
		this.roshambo = roshambo;}

	@Override
	String getRoshambo() {
		return roshambo; }

	@Override
	String generateRoshambo() {
		if (getRoshambo().equalsIgnoreCase("r")) {
			return p1.toString();}
		
		if (getRoshambo().equalsIgnoreCase("p")) {
			return p2.toString();}
		
		if (getRoshambo().equalsIgnoreCase("s")) {
			return p3.toString();}
		
		return ""; } }
