// Created by Daniel Douglas on the 9th day of March 2017.
//  the objective of this program is to allow a user to play Rock Paper Scissors against Bart or Lisa Simpson

import java.util.Scanner;

public class RoshamboApp {
	
	public static void main(String[] args) {
		@SuppressWarnings("resource")
		Scanner sc = new Scanner(System.in);

		System.out.println("What's your name?: ");
		Player1 varG = new Player1();
		varG.setName(sc.nextLine());
		
		String input = "y";
		while (input.equalsIgnoreCase("y")) {
		System.out.println(varG.getName() + ", would you like to play Lisa or Bart? (l/b):  ");
		input = sc.nextLine();
		if (input.isEmpty() || input.length() > 1) {
			System.out.println("Your input appears to be either empty or erroneous.");}
		
		if (input.equalsIgnoreCase("l")) {
			
		Lisa varB = new Lisa();
		varB.setRoshambo(varB.generateRoshambo());
		
		System.out.println("Rock, Paper or Scissors? (r/p/s): ");
		input = sc.nextLine();
		if (input.isEmpty() || input.length() > 1) {
			System.out.println("Your input appears to be either empty or erroneous.");}
		
		varG.setRoshambo(input);
		varG.setRoshambo(varG.generateRoshambo());
		System.out.println(varG.getName()+ " chose: " + varG.getRoshambo() + "\nLisa chose: " + varB.getRoshambo() );
		
		if (varG.getRoshambo().equalsIgnoreCase("Rock") && varB.getRoshambo().equalsIgnoreCase("Rock") || varG.getRoshambo().equalsIgnoreCase("Paper") && varB.getRoshambo().equalsIgnoreCase("Paper") || varG.getRoshambo().equalsIgnoreCase("Scissors") && varB.getRoshambo().equalsIgnoreCase("Scissors")) {
		 System.out.println("\n It's a tie! ");}
		 
		if (varG.getRoshambo().equalsIgnoreCase("Rock") && varB.getRoshambo().equalsIgnoreCase("Paper")) {
		 System.out.println("\n Paper beats Rock. Lisa wins! ");} 
		
		if (varG.getRoshambo().equalsIgnoreCase("Paper") && varB.getRoshambo().equalsIgnoreCase("Rock")) {
			 System.out.println("\n Paper beats Rock. " + varG.getName() +  " wins! ");}
		
		if (varG.getRoshambo().equalsIgnoreCase("Paper") && varB.getRoshambo().equalsIgnoreCase("Scissors")) {
			 System.out.println("\n Scissors beats Paper. Lisa wins! ");}
		
		if (varG.getRoshambo().equalsIgnoreCase("Scissors") && varB.getRoshambo().equalsIgnoreCase("Paper")) {
			 System.out.println("\n Scissors beats Paper. " + varG.getName() +  " wins! ");}
		
		if (varG.getRoshambo().equalsIgnoreCase("Rock") && varB.getRoshambo().equalsIgnoreCase("Scissors")) {
			 System.out.println("\n Rock beats Scissors. " + varG.getName() + " wins! ");}
		
		if (varG.getRoshambo().equalsIgnoreCase("Scissors") && varB.getRoshambo().equalsIgnoreCase("Rock")) {
			 System.out.println("\n Rock beats Scissors. Lisa wins! ");} }
		
		if (input.equalsIgnoreCase("b")) {
			
		Bart varB = new Bart();
		varB.setRoshambo(varB.generateRoshambo());
		
		System.out.println("Rock, Paper or Scissors? (r/p/s): ");
		varG.setRoshambo(sc.nextLine());
		varG.setRoshambo(varG.generateRoshambo());
		System.out.println(varG.getName() + " chose: " + varG.getRoshambo() + "\nBart chose: " + varB.getRoshambo() );
		
		 if (varG.getRoshambo().equalsIgnoreCase("Rock")) {
		 System.out.println("\n It's a tie! ");}
		 
		 if (varG.getRoshambo().equalsIgnoreCase("Paper")) {
		 System.out.println("\n Paper beats rock! " + varG.getName() +" wins!");}
		 
		 if (varG.getRoshambo().equalsIgnoreCase("Scissors")) {
		 System.out.println("\n Rock beats scissors! Bart wins!");}}
	
		System.out.println("\nContinue? (y/n:) ");
		input = sc.nextLine();
		if (input.isEmpty() || input.length() > 1 || !input.equalsIgnoreCase("y")) {
			System.out.println("Your input appears to be either empty or erroneous.");
					System.out.println("\nContinue? (y/n:) ");
					input = sc.nextLine();}} 
		
		System.out.println("Have a good one. "); }}
