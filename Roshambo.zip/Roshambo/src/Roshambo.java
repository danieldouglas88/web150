
public enum Roshambo {
	
	rock, paper, scissors; 
	
	@Override
	public String toString(){
		String string = "";
		if (ordinal() == 0) {
			string = "Rock";} 
		if (ordinal() == 1) {
			string = "Paper";} 
		if (ordinal() == 2) {
			string = "Scissors";} 
		return string; } }
