import java.util.Random;

public class Lisa extends Player{
	
	Roshambo p1 = Roshambo.rock; 
	Roshambo p2 = Roshambo.paper; 
	Roshambo p3 = Roshambo.scissors; 
	
	Random random = new Random();
	
	@Override
	public String generateRoshambo() {
		int  n = random.nextInt(3);
		if (n == (0)) {
			return p1.toString();}
		
		if (n == (1)) {
			return p2.toString();}
		
		if (n == (2)) {
			return p3.toString();}
		return ""; }

	@Override
	void setName(String name) {
		this.name = name; }

	@Override
	String getName() {
		return name; }

	@Override
	void setRoshambo(String roshambo) {
		this.roshambo = roshambo; }

	@Override
	String getRoshambo() {
		return roshambo;}}
